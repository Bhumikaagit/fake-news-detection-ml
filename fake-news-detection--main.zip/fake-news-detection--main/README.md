# fake-news-detection-
fake news detection code in jupyter notebook

# fake-news-detection-ml
"A machine learning project in Python (Jupyter Notebook) to detect fake news using NLP."
